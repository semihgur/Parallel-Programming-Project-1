PARALLEL PROJECT 3

Emirhan Akıtürk 19050111065, Emre Özçatal 20050111074, Semih Gür 19050111017, Abdülsamet Haymana 19050111068

To use this Makefile:

make all will compile all 3 programs
make openmp will compile just the openmp program
make run_openmp will run the openmp program
make clean will delete all compiled programs
Similar targets exist for cuda and seq
